# Boring Go — published outline

Curriculum follows the public Golang College *Boring Go* TOC (topics only).
Prose and programs are original to this library.

## Parts

See `index.qmd` for the reader-facing map.

## Chapter files

### 01-foundations
- 01-why-go-exists.qmd
- 02-installing-and-running-go.qmd
- 03-how-go-code-is-organized.qmd
- 04-go-tour.qmd

### 02-toolchain
- 01-core-go-commands.qmd
- 02-formatting-vetting-documentation.qmd
- 03-dependency-management.qmd
- 04-workspaces-and-multi-module.qmd

### 03-types-and-values
- 01-predeclared-types.qmd
- 02-zero-values-and-initialization.qmd
- 03-constants-and-literals.qmd
- 04-variables-and-scope.qmd

### 04-control-flow
- 01-conditional-logic.qmd
- 02-loops-and-iteration.qmd

### 05-composite-types
- 01-arrays-and-slices.qmd
- 02-working-with-strings.qmd
- 03-maps.qmd
- 04-structs-and-data-modeling.qmd

### 06-functions-and-methods
- 01-functions-in-depth.qmd
- 02-functions-as-values.qmd
- 03-methods-and-receivers.qmd

### 07-memory
- 01-understanding-memory.qmd
- 02-pointers-explained.qmd
- 03-mutability-and-data-sharing.qmd
- 04-garbage-collection.qmd

### 08-interfaces
- 01-designing-with-interfaces.qmd
- 02-interface-best-practices.qmd
- 03-type-assertions-and-reflection-boundaries.qmd

### 09-generics
- 01-why-generics-matter.qmd
- 02-generic-functions.qmd
- 03-generic-types.qmd
- 04-idiomatic-generics.qmd

### 10-errors
- 01-errors-as-values.qmd
- 02-wrapping-and-inspecting.qmd
- 03-panic-recover-failure-modes.qmd

### 11-testing
- 01-testing-fundamentals.qmd
- 02-organization-and-coverage.qmd
- 03-advanced-testing.qmd
- 04-integration-and-system-testing.qmd

### 12-concurrency
- 01-concurrency-basics.qmd
- 02-channel-patterns.qmd
- 03-synchronization.qmd
- 04-context-and-cancellation.qmd
- 05-concurrency-design-guidelines.qmd

### 13-stdlib
- 01-time-and-scheduling.qmd
- 02-io-and-streaming.qmd
- 03-encoding-and-serialization.qmd
- 04-http-and-networking.qmd
- 05-logging-and-observability.qmd

### 14-shipping
- 01-static-analysis-and-security.qmd
- 02-codegen-and-embedding.qmd
- 03-building-and-releasing.qmd
- 04-documentation-and-apis.qmd

### 15-long-term
- 01-reflection-in-practice.qmd
- 02-unsafe-code.qmd
- 03-cgo-and-ffi.qmd
- 04-performance-tuning.qmd
- 05-designing-for-the-long-term.qmd

### 99-appendices
- 01-glossary.qmd
- 02-command-cheat-sheet.qmd
